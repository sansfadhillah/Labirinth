# Changelog
All notable changes to this package will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2018-10-09
release prep

## [0.0.4] - 2018-10-09
ci fixes

## [0.0.3] - 2018-10-08
fix for changelog values.

## [0.0.2] - 2018-10-08
updated to latest upm package template

## [0.0.1] - 2018-10-08

### This is the first release of *Unity Package XR Tools*
Initial move from XR Tools to Legacy Input Helper package

